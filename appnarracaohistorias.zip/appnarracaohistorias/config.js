export const firebaseConfig = {
  
};